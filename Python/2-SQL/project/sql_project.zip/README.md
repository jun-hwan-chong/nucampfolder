Game Concept

This is a database centered around a video concept of an mmorpg where a character has the ability to
summon a unique spirit creature to attack. It is a very barebone database without many columns with the
intent of creating the primary structure first due to time constraints.

Originally my plan was to create a large database with a lot more entities and relationships ie, character stats, weapons, combat abilities, magic abilities etc. but for the purposes of this project, I reduced the scope greatly.